package com.example.quiz;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private QuestionLibrary mQuestionLibrary = new QuestionLibrary();
    private TextView mScoreView;
    private TextView mQuesView;
    private Button mOption1;
    private Button mOption2;
    private Button mOption3;
    private Button mOption4;
    private Button mQuit;
    private String mAnswer;
    private int mScore=0;
    private int mQuestionNumber=0;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mScoreView=(TextView) findViewById(R.id.tvscore);
        mQuesView=(TextView) findViewById(R.id.tvQues);
        mOption1=findViewById(R.id.btnOption1);
        mOption2=findViewById(R.id.btnOption2);
        mOption3=findViewById(R.id.btnOption3);
        mOption4=findViewById(R.id.btnOption4);
        mQuit=findViewById(R.id.btnQuit);

        mOption1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try{
                    if(mOption1.getText()==mAnswer){
                        mScore=mScore+1;
                        updateScore(mScore);
                        updateQuestion();
                        Toast.makeText(MainActivity.this,"Correct", Toast.LENGTH_LONG).show();
                    } else{
                        Toast.makeText(MainActivity.this,"Wrong", Toast.LENGTH_LONG).show();
                        updateQuestion();

                    }
                } catch (Exception e){
                    Toast.makeText(MainActivity.this,"Correct", Toast.LENGTH_LONG).show();

                }

            }
        });


    }

    private void updateQuestion (){
        mQuestionNumber++;

        mQuesView.setText(mQuestionLibrary.getQuestion(mQuestionNumber));
        mOption1.setText(mQuestionLibrary.getOption1(mQuestionNumber));
        mOption1.setText(mQuestionLibrary.getOption2(mQuestionNumber));
        mOption1.setText(mQuestionLibrary.getOption3(mQuestionNumber));
        mOption1.setText(mQuestionLibrary.getOption4(mQuestionNumber));

    }
    private void updateScore(int point){
        mScoreView.setText("Score: "+mScore);
    }
}