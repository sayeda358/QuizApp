package com.example.quiz;

public class QuestionLibrary {
    private String ques [] ={
            " Which star is most famous?",
            " Who is more rich? ",
            " Who is the visual of this group? ",
            " What is nickname of the fans of BlackPink? "

    };

    private String option [][] = {
            {"Jisoo","Lisa","Rose","jennie"},
            {"jennie","Jisoo","Lisa","Rose"},
            {"Rose","jennie","Jisoo","Lisa"},
            {"Lisa","jennie","Jisoo","Rose"}

    };

    private String CorrectAns[]={"Jisoo","Lisa","Rose","jennie"};

    public String getQuestion(int a){
        String question= ques[a];
        return question;
    }
    public String getOption1(int a){
        String option1 = option[a][0];
        return option1;
    }


    public String getOption2(int a){
        String option2 = option[a][1];
        return option2;
    }

    public String getOption3(int a){
        String option3 = option[a][2];
        return option3;
    }

    public String getOption4(int a){
        String option4 = option[a][3];
        return option4;
    }



}
